<?php

namespace App\Http\Controllers;

use App\Exports\UsersExport;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Maatwebsite\Excel\Facades\Excel;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $users = User::get();
        $page_title = 'Users';
        return view('users.index' ,["users" => $users , "page_title" => $page_title]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('users.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required | email | unique:users,email',
        ]);

        $input = $request->only(["name", "email"]);

        $input['password'] = Hash::make('Welcome123'); 

        $user = User::create($input);

        return redirect('/users');

    }

    /**
     * Display the specified resource.
     */
    public function show(User $user)
    {
        return $user->name;
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(User $user)
    {
        return view('users.edit',["user"=>$user]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, User $user)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required | email | unique:users,email,'.$user->id,
        ]);

        $input = $request->only(["name", "email"]);

        $user = $user->fill($input);

        $user->save();

        return redirect('/users');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(User $user)
    {
        $user->delete();

        return redirect('/users');
    }

    public function confirmDelete($user_id){
        $user  = User::find($user_id);
        return view('users.confirm_delete',["user"=>$user]);
    }

    public function login(Request $request) {
        $request->validate([
            'email' => 'required | email',
            'password' => 'required',
        ]);

        $creds = $request->only(['email' ,'password']);

        if(Auth::attempt($creds)){
            return redirect('/users');
        }else{
            Mail::raw("Invalid login attempts detected",function($message) use($request){
                $message->to($request->email)->subject('Invalid Login Attempts');
            });
            return back()->withErrors(["error"=>"Invalid login credentials"]);
        }

    }

        
    public function export() 
    {
        return Excel::download(new UsersExport, 'users.xlsx');
    }
}
