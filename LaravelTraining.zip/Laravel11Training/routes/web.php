<?php

use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('login');
});
Route::get('/login', function () {
    return view('login');
});
Route::get('/logout', function () {
    Auth::logout();
    return redirect('/login');
})->name('logout');

Route::post('/login',[UserController::class, 'login'])->name('login');
Route::group(["middleware"=>"auth"],function(){
    Route::get('/users/export',[UserController::class, 'export'])->name('users.export');
    Route::resource('users',UserController::class);
    Route::get('/users/confirm-delete/{user_id}',[UserController::class,'confirmDelete'])->name('users.confirm_delete');
});
// /user GET
// /user POST Store
// /user/create Create
// user/1 GET show
// /user/1/edit get edit
// /user/1 PUT UPdate
// /user/1 delete Destory
