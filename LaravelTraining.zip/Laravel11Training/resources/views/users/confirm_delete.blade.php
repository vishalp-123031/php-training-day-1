@extends('app')
@section('content')
<div class="mt-3">
    <div class="row">
        <div class="col-md-8">

            <h1 class="page-title">Are you Sure you want to delete {{$user->name}} from the system ?</h1>
        </div>
        <div class="col-md-4 text-end">
            <a href="{{route('users.index')}}" class="btn btn-primary">Go Back</a>
        </div>

        <form method="post" action="{{route('users.destroy',['user'=>$user])}}">
            @csrf
            <input type="hidden" name="_method" value="DELETE">
            <button class="btn btn-primary">Yes</button>
            <a href="{{route('users.index')}}" class="btn btn-danger">Cancel</a>
        </form>
    </div>
</div>
@endsection