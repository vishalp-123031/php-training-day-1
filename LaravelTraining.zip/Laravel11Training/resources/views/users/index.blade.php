@extends('app')
@section('content')
<div class="mt-3">
    <div class="row">
        <div class="col-md-5">

            <h1 class="page-title">{{ $page_title }}</h1>
        </div>
        <div class="col-md-7 text-end">
        <a href="{{route('users.export')}}" class="btn btn-primary">Download Excel</a>
        <a href="{{route('users.create')}}" class="btn btn-primary">Add User</a>
        </div>
    </div>
</div>
<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        @foreach($users as $user)
        <tr>
            <td>{{$user->id}}</td>
            <td>{{$user->name}}</td>
            <td>{{$user->email}}</td>
            <td>
                <a class="btn btn-sm btn-warning" href="{{route('users.edit',['user'=>$user])}}">Edit</a>
                <a class="btn btn-sm btn-danger" href="{{route('users.show',['user'=>$user])}}">View</a> 
                <!-- <form method="post" action="{{route('users.destroy',['user'=>$user])}}">
                    @csrf
                    <input type="hidden" name="_method" value="DELETE">
                    <button class="btn btn-sm btn-danger">Delete</button>
                </form> -->
                <a class="btn btn-sm btn-danger" href="{{route('users.confirm_delete',['user_id'=>$user->id])}}">Delete</a>          
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@endsection