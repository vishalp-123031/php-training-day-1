@extends('app')
@section('content')
<div class="mt-5">
    <form action="{{route('login')}}" method="post">
        @if($errors->has('error'))
        <div class="alert alert-danger">
            {{ $errors->first('error') }}
        </div>
        @endif
        <div class="row">
            <div class="col-md-4 offset-md-4">
                <div>
                    <h2 class="page-title">Login</h2>
                </div>
                <div class="">

                    <div class=" form-group">
                        <label for="email">Email</label>
                        <input type="text" name="email" value="{{old('email')}}">
                        <span class="text-danger">{{$errors->first('email')}}</span>
                    </div>
                    <div class=" form-group">
                        <label for="password">Password</label>
                        <input type="password" name="password" value="{{old('password')}}">
                        <span class="text-danger">{{$errors->first('password')}}</span>
                    </div>
                    @csrf
                    <div class="mt-2">
                        <button class="btn btn-primary">Login</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
@endsection