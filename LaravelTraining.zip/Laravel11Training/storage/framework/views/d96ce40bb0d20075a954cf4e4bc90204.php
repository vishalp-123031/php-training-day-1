<?php $__env->startSection('content'); ?>
<div class="mt-3">
    <div class="row">
        <div class="col-md-5">

            <h1 class="page-title"><?php echo e($page_title); ?></h1>
        </div>
        <div class="col-md-7 text-end">
        <a href="<?php echo e(route('users.export')); ?>" class="btn btn-primary">Download Excel</a>
        <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary">Add User</a>
        </div>
    </div>
</div>
<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($user->id); ?></td>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td>
                <a class="btn btn-sm btn-warning" href="<?php echo e(route('users.edit',['user'=>$user])); ?>">Edit</a>
                <a class="btn btn-sm btn-danger" href="<?php echo e(route('users.show',['user'=>$user])); ?>">View</a> 
                <!-- <form method="post" action="<?php echo e(route('users.destroy',['user'=>$user])); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="_method" value="DELETE">
                    <button class="btn btn-sm btn-danger">Delete</button>
                </form> -->
                <a class="btn btn-sm btn-danger" href="<?php echo e(route('users.confirm_delete',['user_id'=>$user->id])); ?>">Delete</a>          
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/CampusTraining/Day2/Laravel11Training/resources/views/users/index.blade.php ENDPATH**/ ?>