<?php $__env->startSection('content'); ?>
<div class="mt-3">
    <div class="row">
        <div class="col-md-8">

            <h1 class="page-title">Are you Sure you want to delete <?php echo e($user->name); ?> from the system ?</h1>
        </div>
        <div class="col-md-4 text-end">
            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-primary">Go Back</a>
        </div>

        <form method="post" action="<?php echo e(route('users.destroy',['user'=>$user])); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="_method" value="DELETE">
            <button class="btn btn-primary">Yes</button>
            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-danger">Cancel</a>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/CampusTraining/Day2/Laravel11Training/resources/views/users/confirm_delete.blade.php ENDPATH**/ ?>