<?php $__env->startSection('content'); ?>
<div class="mt-3">
    <div class="row">
        <div class="col-md-5">

            <h1 class="page-title">Edit User</h1>
        </div>
        <div class="col-md-7 text-end">
            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-primary">Go Back</a>
        </div>
    </div>

    <div>
        <form action="<?php echo e(route('users.update' ,['user'=>$user])); ?>" method="post">
            <input type="hidden" name="_method" value='put'>
            <div class="row">
                <div class="col-md-5 form-group">
                    <label for="name">Name</label>
                    <input type="text" name="name" value="<?php echo e($user->name); ?>" class="form-control">
                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                </div>
                <div class="col-md-5 form-group">
                    <label for="email">Email</label>
                    <input type="text" name="email" value="<?php echo e($user->email); ?>" class="form-control">
                    <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                </div>
                <?php echo csrf_field(); ?>
                <div class="mt-2">
                    <button class="btn btn-primary">Submit</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/CampusTraining/Day2/Laravel11Training/resources/views/users/edit.blade.php ENDPATH**/ ?>