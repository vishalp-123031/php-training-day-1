$(document).ready(function () {

/***********Start*****************/

//Tooltip Enabled
$('[rel="tooltip"]').tooltip();

const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))


function GetTodayDate() {
  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
  ];
  
  const tdate = new Date();
  var dd = tdate.getDate(); //yields day
  var MM = tdate.getMonth(); //yields month
  var yyyy = tdate.getFullYear(); //yields year
  var currentDate =  dd + "-" + monthNames[tdate.getMonth()]+ "-" + yyyy;

  console.log(currentDate);
  
  if ($('.today-date').length) {
    $('.today-date').text(currentDate);
  }
}
GetTodayDate();


/*DataTable*/
function activateDataTable() {
  if ($('.dataTableInit').length) {
    var tableData =  $('.dataTableInit').DataTable({
      dom: 'Bfrtip',
      lengthChange: !1,
      responsive: !0,
      pageLength: 10,
      buttons: [{
        extend: 'collection',
        text: 'Export',
        buttons: [
          'copy',
          'excel',
          'csv',
          'pdf',
          'print'
        ]
      }
      ]
    });

    //External SEARCH Start
    var search = $.fn.dataTable.util.throttle(
      function (val) {
          tableData.search(val).draw();
      }, 400
    );
    $('#searchAllRequest').keyup(function () {
      search(this.value);
    });
    $('#searchAllRequest').change(function () {
      search(this.value);
    });
    $('#searchAllRequest').on("search", function () {
      search(this.value);
    });
    //External SEARCH End

    //External EXPORT start
    var buttons = new $.fn.dataTable.Buttons(tableData, {
      buttons: [
          {
              extend: 'excelHtml5',
              text: '<i class="bi bi-file-earmark-excel"></i> Excel',
              buttons: {
              text: '<i class="bi bi-file-earmark-excel"></i>',
              titleAttr: 'Excel'
          }
      }
      ],
  }).container().appendTo($('#exportTable'));
  //External EXPORT End
  }
}

setTimeout(function () {
  activateDataTable();
}, 500);

function dataTableNoButtons() {
if ($('.dataTableNoButtons').length) {

  $('.dataTableNoButtons').DataTable({
    dom: 'Bfrtip',
    lengthChange: !1,
    buttons: [],
    searching: false,
  });
}
}

setTimeout(function () {
  dataTableNoButtons();
}, 500);

$(".agent-dashboard-row .dashboard-card-2").click(function () {
  $(".dashboard-card-2").removeClass("active");
  $(this).addClass("active");
  var cardtitle = $(this).find('.card-title').text();
  var cardStatus = $(this).find('.card-title').attr('data-filter');
  $(".active-title-name").text(cardtitle);
  var tableName = $(this).attr("data-name");
  $(".agent-table-cntr").addClass("d-none");
  $('#' + tableName).removeClass("d-none");
});

$(".lead-allocation-row .dashboard-card-2").click(function () {
  $(".dashboard-card-2").removeClass("active");
  $(this).addClass("active");
  var tableName = $(this).attr("data-name");
  $(".agent-lead-table").addClass("d-none");
  $('.' + tableName).removeClass("d-none");
});

function checkHashtag() {   
  var hash = window.location.hash.slice(1);
  if(window.location.hash) {
    $('.'+hash+'').removeClass('d-none');
    $('.noneselected').addClass('d-none');
    $('#allocateSkills').select2('destroy');
    $(".dashboard-card-2[data-name='" +hash+"']").addClass('active');
    $('#allocateSkills').select2({
      width:'100%'
    });
  } else {
  }
}
checkHashtag();

$("#LeadStatus").change(function () {
    $(this).find("option:selected").each(function () {
      var optionValue = $(this).attr("value");
      if (optionValue) {
        $(".hideDiv").not("." + optionValue).hide();
        $("." + optionValue).show();
      } else {
        $(".hideDiv").hide();
      }
    });
}).change();

$("#allocateSkills").change(function () {
    $(this).find("option:selected").each(function () {
      var optionValue = $(this).attr("value");
      if (optionValue) {
        $(".agent-lead-table").not("." + optionValue).addClass('d-none');
        $(".available-leads-box").not("." + optionValue).addClass('d-none');
        $("." + optionValue).removeClass('d-none');
      } else {
        $(".agent-lead-table").addClass('d-none');
        $(".available-leads-box").addClass('d-none');
      }
    });
}).change();

$(".lead-upload-btn").click(function () {
  $(".upload-table-cntr").removeClass("d-none");
  $(".upload-notes-cntr").addClass("d-none");
});

$(".select-exp-level").change(function () {
  $(this).find("option:selected").each(function () {
    var optionValue = $(this).attr("value");
    $(this).parents('td').find('.sel-cntr > div').removeClass();
    $(this).parents('td').find('.sel-cntr > div').addClass(optionValue);
    if ($(this).val() == ('positive')) {
      $(this).parents('tr').next().find('.customSelect').prop('disabled', false);
      $(this).parents('tr').next().find('.form-select').prop('disabled', false);
    } else {
      $(this).parents('tr').next().find('.customSelect').prop('disabled', 'disabled');
      $(this).parents('tr').next().find('.form-select').prop('disabled', 'disabled');
    }
  });
}).change();

  $(document).on('change', '.sel-unit-testing', function (e) {

    if ($(this).val() == ('positive')) {
      $(this).parents('table').find('.customSelect').prop('disabled', false);
      $(this).parents('table').find('.form-select').prop('disabled', false);
      $(this).parents('table').find('.form-control').prop('disabled', false);
    } else {
      $(this).parents('table').find('.customSelect').prop('disabled', 'disabled');
      $(this).parents('table').find('.form-select').prop('disabled', 'disabled');
      $(this).parents('table').find('.form-control').prop('disabled', 'disabled');
    }
  });

  $("#selTeamLead").change(function () {
      $(this).find("option:selected").each(function () {
      var optionValue = $(this).attr("value");
      if ($(this).val() == ('none')) {
        $(".teamlead-name").text('');
      } else {
        $(".teamlead-name").html('for ' + optionValue);
        $(".agent-name").text('');
      }
      });
  }).change();

  $("#selAgent").change(function () {
      $(this).find("option:selected").each(function () {
        var optionValue = $(this).attr("value");
        if ($(this).val() == ('none')) {
          $(".agent-name").text('');        
        } else {
          var optionValue = $(this).attr("value");
          $(".teamlead-name").html('for ' + optionValue);
          $(".agent-name").text('');
        }
      });
  }).change();

  $(".deleteRecord").click(function (e) {
    e.preventDefault();
    $("#deleteRecord").modal("show");
  });

  $(".submitRecord").click(function (e) {
    e.preventDefault();
    $("#successModal").modal("show");

  });

  $(".saveDraftRecord").click(function () {
    $("#successDraftModal").modal("show");
  });


  $(".viewData").click(function () {
    $("#viewFileModal").modal("show");
  });

  function countupTimer() {
    var sec = 0;
      function pad ( val ) { return val > 9 ? val : "0" + val; }
      setInterval( function(){
          $("#seconds").html(pad(++sec%60));
          $("#minutes").html(pad(parseInt(sec / 60 % 60, 10)));
      }, 1000);
  }
  countupTimer();

  //Equal Height
  var winWidth = $(window).width();
  function equalHeightDiv(group) {
    var tallest = 0;
    group.each(function () {
      var thisHeight = $(this).height();
      if (thisHeight > tallest) {
        tallest = thisHeight;
      }
    });
    group.height(tallest);
  }
  equalHeightDiv($('.agent-dash-col .card-title'));

  /* $(".select-file-modal").select2({
    dropdownParent: $('#allocateLeadsModal .modal-content')
  }); */



  /***********End*****************/
});







