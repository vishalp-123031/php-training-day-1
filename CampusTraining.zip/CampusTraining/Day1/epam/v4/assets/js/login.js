

$(document).ready(function () {

  "use strict";

  const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
  const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));

  $(".show-password, .hide-password").on('click', function () {
    var passwordId = $(this).parents('.input-group').find('input').attr('id');
    if ($(this).hasClass('show-password')) {
      $("#" + passwordId).attr("type", "text");
      $(this).parent().find(".show-password").hide();
      $(this).parent().find(".hide-password").show();
    } else {
      $("#" + passwordId).attr("type", "password");
      $(this).parent().find(".hide-password").hide();
      $(this).parent().find(".show-password").show();
    }
  });

  setTimeout(function() {
    $('.alert').fadeOut();  
   }, 2000 );


   $(window).on('load', function () {
    $('.loader-wrapper').hide();
  }) 

});























