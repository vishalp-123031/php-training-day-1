$(window).on('load', function () {
  $('#loading-cntr').hide();
});


//Header Footer Common

if ($('#header').length) {
  $("#header").load("header.html");
}


if ($('#footer').length) {
  $("#footer").load("footer.html");
}

$(document).ready(function () {

  /****************************/
  /******* Theme Change *******/
  $(document).on('click', '.theme-change a', function (e) {
    var themeIconClass = $(this).data('class');
    setActiveTheme(themeIconClass);
    var themeModeClass = $(this).data("theme");
    themeMode(themeModeClass);
  });

  function setActiveTheme(themeIconClass) {
    $('.theme-change li a').removeClass('active');
    $(".theme-dropdown").find('i').removeClass();
    $('.theme-change li [data-class="' + themeIconClass + '"]').addClass('active');
    $(".theme-dropdown").find('i').addClass(themeIconClass);
    localStorage.setItem('activeDropdownItem', themeIconClass);

  }

  var activeDropdownItem = localStorage.getItem('activeDropdownItem');

  setTimeout(function () {
    if (activeDropdownItem) {
      setActiveTheme(activeDropdownItem);
      var themeModeClassCurrent = localStorage.getItem("mode");
      if (themeModeClassCurrent) {
        themeMode(themeModeClassCurrent);
      } else {
        themeMode();
      }
    }
  }, 100);



  function themeMode(themeModeClass) {
    if (themeModeClass === "dark") {
      blackMode();
    } else if (themeModeClass === "Hi-Contrast") {
      contrastMode();

    } else {
      lightMode();
    }
    var themeModeClass = localStorage.getItem("mode");
  }


  function blackMode() {
    localStorage.setItem("mode", "dark");
    $('html').attr('data-bs-theme', 'dark');
    $('.navbar-brand-box img').attr('src', './assets/images/HGS-Logo-white.svg');
  }

  function lightMode() {
    localStorage.setItem("mode", "light");
    $('html').attr('data-bs-theme', 'light');
    $('.navbar-brand-box img').attr('src', './assets/images/HGS-logo.svg');
  }

  function contrastMode() {
    localStorage.setItem("mode", "Hi-Contrast");
    $('html').attr('data-bs-theme', 'Hi-Contrast');
    $('.navbar-brand-box img').attr('src', './assets/images/HGS-Logo-white.svg');

  }
  /****************************/
  /**** Theme Change End ****/


  //Bootstrap Tooltip
  const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
  const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));

  //Equal Height
  var winWidth = $(window).width();
  function equalHeight(group) {
    var tallest = 0;
    group.each(function () {
      var thisHeight = $(this).height();
      if (thisHeight > tallest) {
        tallest = thisHeight;
      }
    });
    group.height(tallest);
  }
  equalHeight($('.dash-card-row .card .card-body'));



  /*********************/
  /***  Full Screen ***/

  function setFullscreen(screenState) {
    $('html').attr('data-fullscreen', screenState);
    localStorage.setItem('fullscreenState', screenState);

    // if (screenState == 'active') {
    //   openFullscreen();
    //   openFullscreenClasses();
    //   console.log('active')
    // } else {
    //   closeFullscreen();
    //   closeFullscreenClasses();
    //   console.log('CLOSE')
    // }

  }


  var fullscreenState = localStorage.getItem('fullscreenState');
  if (fullscreenState) {
    setFullscreen(fullscreenState);
  }

  $(document).on('click', '.start-fullscreen', function () {
    openFullscreen();
    openFullscreenClasses();
    var fullscreenState = 'active';
    setFullscreen(fullscreenState);
  });

  $(document).on('click', '.exit-fullscreen', function () {
    closeFullscreen();
    closeFullscreenClasses();
    var fullscreenState = 'close';
    setFullscreen(fullscreenState);
  });

  var elemScreen = document.documentElement;

  /***  View in fullscreen ***/
  function openFullscreen() {
    if (elemScreen.requestFullscreen) {
      elemScreen.requestFullscreen();
    } else if (elemScreen.webkitRequestFullscreen) { /* Safari */
      elemScreen.webkitRequestFullscreen();
    } else if (elemScreen.msRequestFullscreen) { /* IE11 */
      elemScreen.msRequestFullscreen();
    }
  }

  function openFullscreenClasses() {
    $fullsc = $('.fullScreenEvent')
    $fullsc.removeClass('start-fullscreen');
    $fullsc.addClass('exit-fullscreen');
    $fullsc.find('i').removeClass('bi bi-fullscreen');
    $fullsc.find('i').addClass('bi bi-fullscreen-exit');
  }


  /* Close fullscreen */
  function closeFullscreen() {
    if (document.exitFullscreen) {
      document.exitFullscreen();
    } else if (document.webkitExitFullscreen) {
      document.webkitExitFullscreen();
    } else if (document.mozCancelFullScreen) {
      document.mozCancelFullScreen();
    } else if (document.msExitFullscreen) {
      document.msExitFullscreen();
    }
  }

  function closeFullscreenClasses() {
    $fullsc = $('.fullScreenEvent')
    $fullsc.removeClass('exit-fullscreen');
    $fullsc.addClass('start-fullscreen');
    $fullsc.find('i').addClass('bi bi-fullscreen');
    $fullsc.find('i').removeClass('bi bi-fullscreen-exit');
  }

  //Escape full screen event
  document.addEventListener('fullscreenchange', exitHandler);
  document.addEventListener('webkitfullscreenchange', exitHandler);
  document.addEventListener('mozfullscreenchange', exitHandler);
  document.addEventListener('MSFullscreenChange', exitHandler);

  function exitHandler() {
    if (!document.fullscreenElement && !document.webkitIsFullScreen && !document.mozFullScreen && !document.msFullscreenElement) {
      closeFullscreenClasses();
      var fullscreenState = 'close';
      setFullscreen(fullscreenState);
    }
  }
  /*************************/
  /***  Full Screen End ***/


  /******************************/
  /***** Accessibility Js *******/

  //Accessibility Font-size increse decrese change code //
  var $affectedElements = $("body,span,h1, h2, h3, h4, h5, p, a, label");
  // Can be extended, ex. $("div, p, span.someClass")
  // Storing the original size in a data attribute so size can be reset
  $affectedElements.each(function () {
    var $this = $(this);
    $this.data("orig-size", $this.css("font-size"));
  });
  $(document).on('click', '#btnincrease', function () {
    changeFontSize(1, $affectedElements);
  });
  $(document).on('click', '#btndecrease', function () {
    changeFontSize(-1, $affectedElements);
    // console.log('mahesh');
  });
  $(document).on('click', '#btnorig', function () {
    $affectedElements.each(function () {
      var $this = $(this);
      $this.css("font-size", $this.data("orig-size"));
    });
  });
  function changeFontSize(direction, $affectedElements) {
    $affectedElements.each(function () {
      var $this = $(this);
      $this.css("font-size", parseInt($this.css("font-size")) + direction);
    });
  }
  // $('h1,h2,h3,h4,h5,h6,a,p,li,label,table,tr,th,td').each(function() {
  $('h1,h2,h3,h4,h5,h6,a,p,li,table,tr,th,td').each(function () {
    $(this).attr('tabindex', '0');
    $(".asscibility li").removeAttr('tabindex', '0');
    $("#navbarSupportedContent li").removeAttr('tabindex', '0');
    $(".custom-tab li, .nav-pills li, .nav-wrapper li").removeAttr('tabindex', '0');
  });
  $(document).on('click', '.skipItem a', function (e) {
    var jump = $(this).attr('href');
    var new_position = $(jump).offset();
    $('html, body').stop().animate({ scrollTop: new_position.top }, 500);
    e.preventDefault();
  });
  /******************************/
  /***** Accessibility Js End****/


  /*Datepicker*/
  function activateDatePicker() {
    /* const date = new Date();

    let day = date.getDate();
    let month = date.getMonth() + 1;
    let year = date.getFullYear();
    
    // This arrangement can be altered based on how we want the date's format to appear.
    let currentDate = `${day}-${month}-${year}`; */

    let currentDate = new Date().toLocaleDateString(('en-GB'));

    $('.datepicker').each(function () {
      $(this).datepicker({
        uiLibrary: 'bootstrap5',
        format: 'dd-mmm-yyyy',
        value: currentDate
      })
    });
  }
  activateDatePicker();

  /*Custom Select*/
  function selectInit() {    
    if ($('.customSelect').length) {
      $('.customSelect').each(function() {
        $(this).select2({ 
          dropdownParent: $(this).parent(),
          placeholder: 'Select an option',
          width:'100%'
        });
      })
    }      
  }
  selectInit();

  /*Timepicker*/
  function activateTimePicker() {
    if ($('.wicked-timepicker').length) {
      var options = {
        title: 'Select Time'
      };
      $('.wicked-timepicker').wickedpicker(options);
    }
  }
  activateTimePicker();



  /********************/
  /*****Goto TOP*******/
  $(".back-to-top").click(function () {
    $("html, body").animate({ scrollTop: 0 }, "slow");
    return false;
  });
  /********************/
  /****Goto TOP End***/


  $("#searchInput").on("keyup", function () {
    var $listItems = $("#instructorlist1 option");
    var searchText = $(this).val().toLowerCase();
    var $notFoundMessage = $(".no-results");
    var found = false;
    $listItems.each(function () {
      var listItemText = $(this).text().toLowerCase();
      if (listItemText.indexOf(searchText) === -1) {
        $(this).hide();
      } else {
        $(this).show();
        found = true;
      }
    });
    $notFoundMessage.toggle(!found);

  });


  //Scroll Bar
  // function simplebarInit() {
  //   setTimeout(function () {
  //     $('.simple-bar').each(function () {
  //       new SimpleBar($(this)[0])
  //     });
  //   }, 100);

  //   setTimeout(function () {
  //     $('.simple-bar-menu').each(function () {
  //       new SimpleBar($(this)[0])
  //     });
  //   }, 100);
  // }
  // simplebarInit();

  // function simplebarDestory() {
  //   setTimeout(function () {
  //     $('.simple-bar').each(function () {
  //       new SimpleBar($(this)[1])
  //       //simpleBar.unMount()
  //     });

  //     $('.sidebar-wrapper').removeAttr("data-simplebar");

  //   }, 100);
  // }
  // simplebarDestory();

  //Code Switcher
  $('.code-switcher').change(function () {
    if (this.checked) {
      $(this).parent().parent().parent().find('.live-preview').addClass("d-none");
      $(this).parent().parent().parent().find('.code-view').removeClass("d-none");
    } else {
      $(this).parent().parent().parent().find('.code-view').addClass("d-none");
      $(this).parent().parent().parent().find('.live-preview').removeClass("d-none");
    }
  });

  $('#customizer-vertical').click(function () {
    if ($(this).is(':checked')) {
      $('html').attr('data-layout', 'verticle');
      $("#menu-toggle-btn").show();

      //simplebarInit();
    }
  });

  $('#customizer-horizontal').click(function () {
    if ($(this).is(':checked')) {
      $('html').attr('data-layout', 'horizontal');
      $("#menu-toggle-btn").hide();
      // simplebarDestory();
    }
  });

  //Set Menu Style
  function setMenuLayout(menuStyle) {
    $('html').attr('data-layout', menuStyle);
    localStorage.setItem('menuLayout', menuStyle);
    $('input[type=radio][name=menuStyle][value="' + menuStyle + '"]').prop('checked', true);
    //$(':radio[value="' + menuStyle + '"]').attr('checked', 'checked');
    if (menuStyle == 'horizontal') {

      // setTimeout(function () {
      //   $(".sidebar-wrapper").removeClass("simple-bar-menu");
      //   simplebarDestory();
      // }, 100);

    } else {

      // setTimeout(function () {
      //   $(".sidebar-wrapper").addClass("simple-bar-menu");
      //   simplebarInit();
      //   console.log('sandip');
      // }, 100);
    }

    if (menuStyle == 'vertical') {
      $("#sidebar").removeClass("collapsed");
      $(".main-layout").addClass("sidebar-open");
    }

    if (menuStyle == 'menuhide') {
      setTimeout(function () {
        $("#sidebar").addClass("collapsed");
        $(".main-layout").removeClass("sidebar-open");
      }, 100);
    }


  }


  $(document).on("change", "input[type=radio][name=menuStyle]", function () {
    var url = $(location).attr('href');
    var parts = url.split("/");
    var last_part = parts[parts.length - 1];
    var last_part = String(last_part).replace(/#/, "");

    $('.navbar-nav li a[href="' + last_part + '"]').parent().parent().removeClass('show');
    $('.navbar-nav li a[href="' + last_part + '"]').parent().parent().parent().find('.dropdown-toggle').removeClass('show');


    var menuLayout = $(this).val();
    //setMenuLayout(menuLayout);

    //setMenuLayout(nomenu);
    setMenuLayout(horizontal);
    //setMenuLayout(vertical);

  });

  var menuLayout = localStorage.getItem('nomenu');
  if (menuLayout) {
    setMenuLayout(menuLayout);
  }


  //Font Famiily
  function setFontFamily(fontFamily) {
    $('body').css('font-family', fontFamily);
    localStorage.setItem('selectedFont', fontFamily);
    $('input[type=radio][name=setFontFamily][value="' + fontFamily + '"]').prop('checked', true);
  }

  $('input[type=radio][name=setFontFamily]').change(function () {
    var selectedFont = $(this).val();
    setFontFamily(selectedFont);
  });

  var selectedFont = localStorage.getItem('selectedFont');
  if (selectedFont) {
    setFontFamily(selectedFont);
  }



  $('.checkAll').click(function () {
    var checked_status = this.checked;
    $(this).closest('table').find('.tCheckBox').each(function () {
      this.checked = checked_status;
    });
  });

  $(".tCheckBox").click(function () {
    var numberOfCheckboxes = $(".tCheckBox").length;
    var numberOfCheckboxesChecked = $('.tCheckBox:checked').length;
    if (numberOfCheckboxes == numberOfCheckboxesChecked) {
      $(this).closest('table').find('.checkAll').prop("checked", true);
    } else {
      $(this).closest('table').find('.checkAll').prop("checked", false);
    }
  });


});


$(document).ready(function () {
  // URL of the JSON data
  //var jsonDataUrlBoostrap = '../ver-5/assets/css/fonts/bootstrap/bootstrap-icons-font-list.json';
  var jsonDataUrlBoostrap = './assets/css/fonts/bootstrap/bootstrap-icons-font-list.json';
  // Fetch JSON data
  $.ajax({
    url: jsonDataUrlBoostrap,
    dataType: 'json',
    success: function (data) {
      // Iterate through the JSON data
      $.each(data, function (index, item) {
        // Create a new div element for each item
        var $div = $('<li class="col mb-4" data-name="' + item.name + '" data-tags="number numeral" data-categories="shapes">');

        // Populate the div with data
        $div.html(`<a class="d-block text-body-emphasis text-decoration-none" target="_blank"
        href="https://icons.getbootstrap.com/icons/` + item.name + `">
        <div class="px-3 py-4 mb-2 bg-body-secondary text-center rounded">
            <i class="bi bi-` + item.name + `"></i>
        </div>
        <div class="name text-muted text-decoration-none text-center pt-1">` + item.name + `
        </div>
        </a>`);

        // Append the div to the data container
        $('#icons-list-boostrap').append($div);
      });
    },
    error: function () {
      // Handle any errors that may occur during the request
      console.error('Failed to fetch JSON data');
    }
  });


  //var jsonDataUrlBoostrap = '../ver-5/assets/css/fonts/RemixIcon_Fonts_v3.5.0/remixicon-icons-font-list.json';
  var jsonDataUrlBoostrap = './assets/css/fonts/RemixIcon_Fonts_v3.5.0/remixicon-icons-font-list.json';
  // Fetch JSON data
  $.ajax({
    url: jsonDataUrlBoostrap,
    dataType: 'json',
    success: function (data) {
      // Iterate through the JSON data
      $.each(data, function (index, item) {
        // Create a new div element for each item
        var $div = $('<li class="col mb-4" data-name="' + item.name + '" data-tags="number numeral" data-categories="shapes">');

        // Populate the div with data
        $div.html(`<a class="d-block text-body-emphasis text-decoration-none" target="_blank"
        href="https://remixicon.com/icon/` + item.name + `">
        <div class="px-3 py-4 mb-2 bg-body-secondary text-center rounded">
            <i class="ri-` + item.icon_name + `"></i>
        </div>
        <div class="name text-muted text-decoration-none text-center pt-1">` + item.name + `
        </div>
        </a>`);

        // Append the div to the data container
        $('#icons-list-remix').append($div);
      });
    },
    error: function () {
      // Handle any errors that may occur during the request
      console.error('Failed to fetch JSON data');
    }
  });

  //Search Icon
  var $block = $('.no-results');
  $('#searchICON').on('input', function () {
    var searchText = $(this).val().toLowerCase();
    var isMatch = false;
    $('.icons-list-font .name').each(function () {
      var listItemText = $(this).text().toLowerCase();
      if (listItemText.indexOf(searchText) !== -1) {
        $(this).parent().parent().show();
        isMatch = true;
      } else {
        $(this).parent().parent().hide();
      }
    });
    $block.toggle(!isMatch);
  });





});

