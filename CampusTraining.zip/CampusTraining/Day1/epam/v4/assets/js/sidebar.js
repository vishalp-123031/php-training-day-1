
$(document).ready(function () {
    //Side Bar Common
    if ($('#menubar').length) {
        $("#menubar").load("side-bar.html");
    }

    if ($('#menubarVendor').length) {
        $("#menubarVendor").load("side-bar-vendor.html");
    }

    // Toggle the side navigation
    $(document).on("click", "#menu-toggle-btn", function () {
        $(".main-layout").toggleClass("sidebar-open");
        $(".app-sidebar").toggleClass("collapsed");
        if ($(".app-sidebar").hasClass("collapsed")) {
            $('.app-sidebar .collapse').collapse('hide');
        };
        $(".sidebar-wrapper").toggleClass("simple-bar");
        $("#sidebar").find('.menu-title').toggleClass("hide");
        removeNavigation();
    });

    // if ($('html').attr('data-layout') == 'horizontal') {}



    //Set active side navigation
    function setNavigation() {
        $(function () {
            var url = $(location).attr('href');
            var parts = url.split("/");
            var last_part = parts[parts.length - 1];
            var last_part = String(last_part).replace(/#/, "");
            //var pathname = window.location.pathname.split("/")[1];


            if ($('.navbar-nav li a[href="' + last_part + '"]').parent().hasClass("single-menu")) {
                $('.navbar-nav li a[href="' + last_part + '"]').parent().addClass('active');
            } else {

                $('.navbar-nav li a[href="' + last_part + '"]').parent().addClass('active');
                $('.navbar-nav li a[href="' + last_part + '"]').parent().parent().parent().addClass('active');

                if ($('html').attr('data-layout') == 'vertical') {
                    $('.navbar-nav li a[href="' + last_part + '"]').parent().parent().parent().find('.dropdown-menu').addClass('show');
                    $('.navbar-nav li a[href="' + last_part + '"]').parent().parent().parent().find('.dropdown-toggle').addClass('show');
                }
            }
        });
    }

    setTimeout(function () {
        setNavigation();
    }, 100);

    //Set active side navigation
    function removeNavigation() {
        $(function () {
            var url = $(location).attr('href');
            var parts = url.split("/");
            var last_part = parts[parts.length - 1];
            var last_part = String(last_part).replace(/#/, "");
            //var pathname = window.location.pathname.split("/")[1];
            $('.navbar-nav li a[href="' + last_part + '"]').parent().addClass('active');
            $('.navbar-nav li a[href="' + last_part + '"]').parent().parent().parent().addClass('active');

            if ($('html').attr('data-layout') == 'vertical') {
                $('.navbar-nav li a[href="' + last_part + '"]').parent().parent().parent().find('.dropdown-menu').removeClass('show');
                $('.navbar-nav li a[href="' + last_part + '"]').parent().parent().parent().find('.dropdown-toggle').removeClass('show');
            }

        });
    }
});












