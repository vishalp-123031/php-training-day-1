<?php
session_start();
function login($post)
{
    $conn = db_connect();
    $username = mysqli_real_escape_string($conn , $post['username']);
    $password = md5($post['password']);

    $query = "SELECT * FROM users where username='$username' and password = '$password' and status=1 limit 1";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        // output data of each row
        $row = $result->fetch_assoc();
        echo "id: " . $row["id"] . " - Name: " . $row["username"] . " " . $row["password"] . "<br>";
        
        if (isset($row['username'])) {
            $username = $row['username'];
        }
        $_SESSION['username'] = $username;
    } else {
        echo "Invalid credentials";
    }
    $conn->close();

    
}

function register($post)
{
    $conn = db_connect();
    $username = mysqli_real_escape_string($conn , $post['username']);
    $password = md5($post['password']);
    $confirm_password = md5($post['confirm_password']);
    
    if(empty($username)){
        die('username field is required');
    }
    if(empty($password)){
        die('password field is required');
    }
    if(empty($confirm_password)){
        die('confirm password field is required');
    }

    if($password !== $confirm_password){
        die('password is not matching with confirm password');
    }

    $query = "SELECT * FROM users where username='$username' limit 1";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        // output data of each row
        die('A user with this username is already exist');
    } else {
        $created_at = date('Y-m-d H:i:s');
        $inertQry = "INSERT INTO users(username,`password`,created_at) VALUES('$username' , '$password' ,'$created_at')";

        $record = $conn->query($inertQry);

        print('You have successfully registerd');
    }
    $conn->close();

    
}

function logout()
{
    session_destroy();
}

function db_connect()
{

    $servername = 'localhost';
    $username = 'root';
    $password = '';
    $dbname = 'db_epam';
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    return $conn;
}
db_connect();
