<?php
   require_once "functions.php";
   if(isset($_POST['login'])){
    login($_POST);
   }
   if(isset($_POST['logout'])){
    logout();
   }
?>

<form method="POST" >
    <h1>Hello <?= $_SESSION['username'] ?></h1>
    <label>Name</label>
    <input autocomplete="off" name="username" type="text" />
    <input autocomplete="off" name="password" type="password" />
    <input name="login" value="Login" type="submit">
    <input name="logout" value="Logout" type="submit">
</form>