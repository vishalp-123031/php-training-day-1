<?php

$a = "2";
$b ="2$a";
$c = $b;
// echo $c;

/* $laptops = [
    "dell1" => ["name" => "Dell LTD", "year" => "2024", "assigned_to" => "Chirag"],
]; */

$laptops = ["dell", "hp", "lenovo"];
print_r($laptops);

array_push($laptops, "macbook");

print_r($laptops);

array_unshift($laptops, "samsung");

print_r($laptops);


//print($laptops["dell"]);

/* $cars = ["audi" => ["model"=>"abc", "maufacturing_year" => "2023"],"maruti","hyundai","tata"];

foreach($cars as $car){
    echo $car;
} */