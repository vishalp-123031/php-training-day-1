<?php
require_once "functions.php";
?>
<h1>About <?= $_SESSION['name'] ?></h1>