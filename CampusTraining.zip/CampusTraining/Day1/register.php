<?php 
    require_once "functions.php";
    if(isset($_POST['Register'])){
     register($_POST);
    }
?>
<html>
<head>
    <title>User Registration</title>
</head>
<body>
    <div>
        <form method="post">

            <table border="1">
                <tr>
                    <th>Username</th>
                    <td>
                        <input name=username type="text">
                    </td>
                </tr>
                <tr>
                    <th>Password</th>
                    <td>
                        <input name=password type="password">
                    </td>
                </tr>
                <tr>
                    <th>Confirm Password</th>
                    <td>
                        <input name=confirm_password type="text">
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <input value="register" type="submit" name="Register">
                    </td>
                </tr>
            </table>
        </form>
    </div>
</body>
</html>